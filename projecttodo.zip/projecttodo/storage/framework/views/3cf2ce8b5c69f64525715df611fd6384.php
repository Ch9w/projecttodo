<style>
    body {
        font-family: Calibri;
        background-image: url(https://celes.club/uploads/posts/2023-03/1679528426_celes-club-p-sinyaya-kletka-fon-vkontakte-1.jpg);
    }

    input {
        font-family: Calibri;
    }

    .d1 {
        display: flex;
        justify-content: center;
    }

    .d2 {
        min-width: 1000px;
    }

    .createtask {
        text-decoration: none;
        color: black;
        width: fit-content;
        text-align: center;
        font-size: 16px;
        background-color: whitesmoke;
        padding: 6px 10px 6px 10px;
        border: 2px black solid;
        border-radius: 6px;
        transition: all ease-in-out 0.15s;
        font-weight: bolder;
    }

    .createtask:hover {
        box-shadow: 0px 4px 8px 2px black;
    }
</style>
<div class="d1">
    <div class="d2">
        <h1 style="text-align: center; color: white;">Мои задачи</h1>
        <div style="text-align: center;">
            <a class='createtask' href="createtask">Создать задачу</a>
            <a class='createtask' href="logout">Выйти</a>
        </div>
        <?php $__currentLoopData = $tasks1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style='background-color: rgb(255, 255, 155); border:1px black solid; border-radius: 6px; padding-left: 6px; padding-right: 6px;'>
            <h3>Заголовок: <?php echo e($task->head); ?></h3>
            <p>Задача: <?php echo e($task->description); ?></p>
            <div style="display: flex;">
                <form style="margin: 0 6px 6px 0;" method="POST" action="agreeTask">
                    <?php echo csrf_field(); ?>
                    <input name="agree" value="<?php echo e($task->id); ?>" hidden>
                    <input type="submit" value="Выполнить">
                </form>
                <form style="margin: 0 6px 6px 0;" method="POST" action="editTask1">
                    <?php echo csrf_field(); ?>
                    <input name="edit" value="<?php echo e($task->id); ?>" hidden>
                    <input type="submit" value="Изменить">
                </form>
                <form style="margin: 0 6px 6px 0;" method="POST" action="delTask">
                    <?php echo csrf_field(); ?>
                    <input name="del" value="<?php echo e($task->id); ?>" hidden>
                    <input type="submit" value="Удалить">
                </form>
            </div>
        </div>
        <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $tasks2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style='background-color: rgb(155, 255, 155);; border:1px black solid; border-radius: 6px; padding-left: 6px; padding-right: 6px;'>
            <h3>Заголовок: <?php echo e($task->head); ?></h3>
            <p>Задача: <?php echo e($task->description); ?></p>
            <div style="display: flex;">
                <form style="margin: 0 6px 6px 0;" method="POST" action="delTask">
                    <?php echo csrf_field(); ?>
                    <input name="del" value="<?php echo e($task->id); ?>" hidden>
                    <input type="submit" value="Удалить">
                </form>
            </div>
        </div>
        <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\Programs\OSPanel\domains\projecttodo\resources\views/tasks.blade.php ENDPATH**/ ?>