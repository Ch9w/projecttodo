<form method='POST' action="authorization">
    <?php echo csrf_field(); ?>
    <h1>Авторизация</h1>
    <table>
        <tr>
            <td>Логин</td>
            <td><input id="login" name="login" type="text" placeholder="Ваш логин" value="">
                <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </td>
        </tr>
        <tr>
            <td>Пароль</td>
            <td><input id="password" name="password" type="password" value="" placeholder="Пароль">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </td>
        </tr>
        <tr>
            <?php $__errorArgs = ['auth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </tr>
    </table>
    <div>
        <button name="sendMe" value="1">Войти</button>
    </div>
</form>
</body>
<style>
html,
body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif
}

body {
    display: flex;
    justify-content: center;
}
</style>
<?php /**PATH C:\OSPanel\domains\lomov\projecttodo\resources\views/authorization.blade.php ENDPATH**/ ?>