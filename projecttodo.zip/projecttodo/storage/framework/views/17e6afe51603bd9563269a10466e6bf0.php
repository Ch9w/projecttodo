<style>
    .d1 {
        display: flex;
        justify-content: center;
    }

    .d2 {
        min-width: 1000px;
    }
</style>
<div class="d1">
    <div class="d2">

        <h1 style="text-align: center;">Задачи</h1>
        <a href="createtask">Создать задачу</a>
        <h1 style="text-align: center;">Мои задачи</h1>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style='border:1px black solid; border-radius: 6px; padding-left: 6px; padding-right: 6px;'>
            <h3>Заголовок: <?php echo e($task->head); ?></h3>
            <p>Задача: <?php echo e($task->description); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\lomov\projecttodo\resources\views/tasks.blade.php ENDPATH**/ ?>