<style>
    body {
        font-family: Calibri;
        background-image: url(https://celes.club/uploads/posts/2023-03/1679528426_celes-club-p-sinyaya-kletka-fon-vkontakte-1.jpg);
    }

    input {
        font-family: Calibri;
        font-size: 18px;
        border: 2px solid white;
        border-radius: 4px;
        background: transparent;
        color:white;
    }

    textarea {
        font-family: Calibri;
        font-size: 18px;
        border: 2px solid white;
        border-radius: 4px;
        background: transparent;
        color:white;
    }

    .d1 {
        display: flex;
        justify-content: center;
    }

    .d2 {
        min-width: 1000px;
    }

    .createtask {
        text-decoration: none;
        color: black;
        width: fit-content;
        text-align: center;
        font-size: 14px;
        background-color: whitesmoke;
        padding: 6px 10px 6px 10px;
        border: 2px black solid;
        border-radius: 6px;
        transition: all ease-in-out 0.15s;
        font-weight: bolder;
    }

    .createtask:hover {
        box-shadow: 0px 4px 8px 2px black;
    }
    .d3 {
        display: flex;
        justify-content: center;
    }
</style>
<div class="d1">
    <div class="d2">
        <h1 style="text-align: center; color:white;">Изменение задачи</h1>
        <div class="d3">
        <form style="width:fit-content;" method="POST" action="editTask2">
            <?php echo csrf_field(); ?>
            <input type="text" name="idedittask" value="<?php echo e($edittask->id); ?>" hidden>
            <table>
                <tr>
                    <td style="color:white; font-size: 20px;">Название задачи</td>
                    <td><input type="text" name="title" value="<?php echo e($edittask->head); ?>"></td>
                </tr>
                <tr>
                    <td style="text-align: left; vertical-align:top; color:white; font-size: 20px;">Описание</td>
                    <td><textarea cols="100" rows="10" name="description"><?php echo e($edittask->description); ?></textarea></td>
                </tr>
                <tr style="text-align: center;">
                    <td colspan="2"><button class="createtask" type="submit">Изменить задачу</button><a style="margin: 0 0 0 10px;" class="createtask" href="tasks">Отмена</a></td>
                </tr>
            </table>
        </form>
        </div>
    </div>
</div><?php /**PATH D:\Programs\OSPanel\domains\projecttodo\resources\views/edittask.blade.php ENDPATH**/ ?>