<style>
    body {
        font-family: Calibri;
        display: flex;
        justify-content: center;
    }

    .sendMe {
        width: 100%;
    }

    table {
        font-size: 18px;
    }

    input {
        font-size: 14px;
        min-width: 200px;
        font-family: Calibri;
    }
</style>
<form method='POST' action="registration">
    <?php echo csrf_field(); ?>
    <h1 style="text-align: center;">Регистрация</h1>
    <table>
        <tr>
            <td>Логин</td>
            <td><input id="login" name="login" type="text" placeholder="Ваш логин" value="">
                <?php $__errorArgs = ['login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td>Пароль</td>
            <td><input id="password" name="password" type="password" value="" placeholder="Пароль">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td>Повторите пароль</td>
            <td><input id="repeatpassword" name="repeatpassword" type="password" value="" placeholder="Повторите пароль">
                <?php $__errorArgs = ['password_repeat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td colspan="2"><button class="sendMe" name="sendMe" value="1">Зарегистрироваться</button></td>
        </tr>
        <tr>
            <td> <a href="authorization">Уже есть аккаунт?</a>
            </td>
        </tr>
    </table>
</form><?php /**PATH D:\Programs\OSPanel\domains\projecttodo\resources\views/registration.blade.php ENDPATH**/ ?>