<style>
    .d1 {
        display: flex;
        justify-content: center;
    }
    .d2 {
        min-width: 1000px;
    }
</style>
<div class="d1">
    <div class="d2">

        <h1 style="text-align: center;">Создание задачи</h1>
        <form method="POST" action="postTask">
            <?php echo csrf_field(); ?>
            <table>
                <tr>
                    <td>Название задачи</td>
                    <td><input type="text" name="title"></td>
                </tr>
                <tr>
                    <td>Описание</td>
                    <td><textarea cols="100" rows="10" name="description"></textarea></td>
                </tr>
                <tr>
                    <td><button type="submit">Создать задачу</button></td>
                </tr>
            </table>
        </form>

    </div>
</div>
<?php /**PATH C:\OSPanel\domains\lomov\projecttodo\resources\views/createtask.blade.php ENDPATH**/ ?>