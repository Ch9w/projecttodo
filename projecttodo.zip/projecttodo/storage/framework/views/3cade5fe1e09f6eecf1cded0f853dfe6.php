<style>
    .d1 {
        display: flex;
        justify-content: center;
    }
    .d2 {
        min-width: 1000px;
    }
</style>
<div class="d1">
    <div class="d2">

        <h1 style="text-align: center;">Задачи</h1>
        <a href="createtask">Создать задачу</a>
        <h1 style="text-align: center;">Мои задачи</h1>
        
    </div>
</div>
<?php /**PATH C:\OSPanel\domains\lomov\projecttodo\resources\views//tasks.blade.php ENDPATH**/ ?>