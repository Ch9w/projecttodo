<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\TasksController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/logout', function () {
    Auth::logout();
    return redirect('authorization');
})->name('logout');

Route::get('/registration', function () {
    return view('registration');
})->name('registration');
Route::post('/registration', [UsersController::class, 'registration']);
Route::get('/authorization', function () {
    return view('authorization');
})->name('authorization');
Route::post('/authorization', [UsersController::class, 'authorization']);

Route::middleware(['auth'])->group(function () {
    Route::get('/tasks', [TasksController::class, 'getTasks'])->name('tasks');
    Route::post('/tasks', [TasksController::class, 'postTasks']);
    Route::get('/createtask', function () {return view('createtask');})->name('createtask');
    Route::post('/postTask', [TasksController::class, 'postTask']);
    Route::post('/delTask', [TasksController::class, 'delTask']);
    Route::post('/agreeTask', [TasksController::class, 'agreeTask']);
    Route::post('/editTask1', [TasksController::class, 'editTask1']);
    Route::post('/editTask2', [TasksController::class, 'editTask2']);
});
