<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Tasks;

class TasksController extends Controller
{
    //
    public function getTasks()
    {
        $tasks1 = Tasks::where('user_id', Auth::id())->where('done', 0)->orderBy('id', 'desc')->get();
        $tasks2 = Tasks::where('user_id', Auth::id())->where('done', 1)->orderBy('id', 'desc')->get();
        return view('tasks', ['tasks1'=> $tasks1, 'tasks2'=> $tasks2]);
    }
    public function postTask(Request $request)
    {
        $head = $request->input('title');
        $description = $request->input('description');
        Tasks::create(([
            'head' => $head,
            'description' => $description,
            'user_id' => Auth::id(),
            'done' => false
        ]));
        return redirect(route('tasks'));
    }
    public function delTask(Request $request) {
        Tasks::find($request->input('del'))->delete();
        return redirect()->to(route('tasks'));
    }
    public function agreeTask(Request $request) {
        $task = Tasks::find($request->input('agree'));
        $task->done = true;
        $task->save();
        return redirect()->to(route('tasks'));
    }
    public function editTask1(Request $request) {
        $edittask = Tasks::find($request->input('edit'));
        return view('edittask', ['edittask'=> $edittask]);
    }
    public function editTask2(Request $request) {
        $edittask = Tasks::find($request->input('idedittask'));
        $edittask->head = $request->input('title');
        $edittask->description = $request->input('description');
        $edittask->save();
        return redirect()->to(route('tasks'));
    }




}
