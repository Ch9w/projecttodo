<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Users;
use Illuminate\Support\Facades\Auth;


class UsersController extends Controller
{
    public function registration(Request $request)
    {
        $login = $request->input('login');
        $password = $request->input('password');
        $repeatpassword = $request->input('repeatpassword');
        if ($password == $repeatpassword) {
            if (Users::where('login', $login)->exists()) {
                return redirect(route('registration'))->withErrors(["login" => "Такой login уже зарегистрирован"]);
            }
            $user = Users::create([
                'login' => $login,
                'password' => $password,
            ]);
            if ($user) {
                Auth::login($user);
                return redirect()->to(route('tasks'));
            }
        } else {
            return redirect(route('registration'))->withErrors(["password_repeat" => "Пароли не совпадают"]);
        }
        return view('registration');
    }
    public function authorization(Request $request)
    {
        $login = $request->input('login');
        $password = $request->input('password');
        if (Users::where('login', $login)->where('password', $password)->exists()) {
            $user = Users::where('login', $login)->first();
            Auth::login($user);
            return redirect(route('tasks'));
        } else {
            return redirect(route('authorization'))->withErrors(["auth" => "Вы не авторизовались"]);
        }
    }
}
