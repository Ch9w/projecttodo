<style>
    body {
        font-family: Calibri;
        background-image: url(https://celes.club/uploads/posts/2023-03/1679528426_celes-club-p-sinyaya-kletka-fon-vkontakte-1.jpg);
    }

    input {
        font-family: Calibri;
    }

    .d1 {
        display: flex;
        justify-content: center;
    }

    .d2 {
        min-width: 1000px;
    }

    .createtask {
        text-decoration: none;
        color: black;
        width: fit-content;
        text-align: center;
        font-size: 16px;
        background-color: whitesmoke;
        padding: 6px 10px 6px 10px;
        border: 2px black solid;
        border-radius: 6px;
        transition: all ease-in-out 0.15s;
        font-weight: bolder;
    }

    .createtask:hover {
        box-shadow: 0px 4px 8px 2px black;
    }
</style>
<div class="d1">
    <div class="d2">
        <h1 style="text-align: center; color: white;">Мои задачи</h1>
        <div style="text-align: center;">
            <a class='createtask' href="createtask">Создать задачу</a>
            <a class='createtask' href="logout">Выйти</a>
        </div>
        @foreach ($tasks1 as $task)
        <div style='background-color: rgb(255, 255, 155); border:1px black solid; border-radius: 6px; padding-left: 6px; padding-right: 6px;'>
            <h3>Заголовок: {{$task->head}}</h3>
            <p>Задача: {{$task->description}}</p>
            <div style="display: flex;">
                <form style="margin: 0 6px 6px 0;" method="POST" action="agreeTask">
                    @csrf
                    <input name="agree" value="{{$task->id}}" hidden>
                    <input type="submit" value="Выполнить">
                </form>
                <form style="margin: 0 6px 6px 0;" method="POST" action="editTask1">
                    @csrf
                    <input name="edit" value="{{$task->id}}" hidden>
                    <input type="submit" value="Изменить">
                </form>
                <form style="margin: 0 6px 6px 0;" method="POST" action="delTask">
                    @csrf
                    <input name="del" value="{{$task->id}}" hidden>
                    <input type="submit" value="Удалить">
                </form>
            </div>
        </div>
        <br>
        @endforeach
        @foreach ($tasks2 as $task)
        <div style='background-color: rgb(155, 255, 155);; border:1px black solid; border-radius: 6px; padding-left: 6px; padding-right: 6px;'>
            <h3>Заголовок: {{$task->head}}</h3>
            <p>Задача: {{$task->description}}</p>
            <div style="display: flex;">
                <form style="margin: 0 6px 6px 0;" method="POST" action="delTask">
                    @csrf
                    <input name="del" value="{{$task->id}}" hidden>
                    <input type="submit" value="Удалить">
                </form>
            </div>
        </div>
        <br>
        @endforeach
    </div>
</div>