<style>
    body {
        font-family: Calibri;
        display: flex;
        justify-content: center;
    }

    .sendMe {
        width: 100%;
    }

    table {
        font-size: 18px;
    }

    input {
        font-size: 14px;
        min-width: 200px;
        font-family: Calibri;
    }
</style>
<form method='POST' action="registration">
    @csrf
    <h1 style="text-align: center;">Регистрация</h1>
    <table>
        <tr>
            <td>Логин</td>
            <td><input id="login" name="login" type="text" placeholder="Ваш логин" value="">
                @error('login')
                <div>{{ $message }}</div>
                @enderror
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td>Пароль</td>
            <td><input id="password" name="password" type="password" value="" placeholder="Пароль">
                @error('password')
                <div>{{ $message }}</div>
                @enderror
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td>Повторите пароль</td>
            <td><input id="repeatpassword" name="repeatpassword" type="password" value="" placeholder="Повторите пароль">
                @error('password_repeat')
                <div>{{ $message }}</div>
                @enderror
            </td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <td colspan="2"><button class="sendMe" name="sendMe" value="1">Зарегистрироваться</button></td>
        </tr>
        <tr>
            <td> <a href="authorization">Уже есть аккаунт?</a>
            </td>
        </tr>
    </table>
</form>